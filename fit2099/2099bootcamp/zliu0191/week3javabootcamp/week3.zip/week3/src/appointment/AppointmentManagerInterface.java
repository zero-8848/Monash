package appointment;

import appointment.Appointment;

public interface AppointmentManagerInterface {
    void addAppointment(int patientId,int doctorId,String date, Appointment.AppointmentType appType);
    void cancelAppointment(int appointmentId);
    void printAppointments();
}