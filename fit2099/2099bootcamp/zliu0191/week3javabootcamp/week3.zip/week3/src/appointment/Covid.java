
package appointment;

import java.util.ArrayList;
import java.util.List;

public class Covid extends Appointment
{
    private List<String> doseDates = new ArrayList<>();

    public Covid(int patientId, int doctorId, String date, AppointmentType covid) {
        super(patientId, doctorId, date, AppointmentType.COVID);
    }

    @Override
    public String toString() {
        String apid=String.format(" %-10s |",super.getAppointmentId());
        String dDate=String.format(" %-10s |","doseDates=" + doseDates);
        return   apid+dDate;
    }
}
