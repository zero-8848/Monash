package appointment;

public class Standard extends Appointment{
private String caseDescription;

    public Standard(int patientId, int doctorId, String date, AppointmentType covid) {
        super(patientId, doctorId, date, AppointmentType.STANDARD);
        this.caseDescription="";
    }

    @Override
    public String toString() {
        String apid=String.format(" %-10s |",super.getAppointmentId());
        String ca=String.format(" %-10s |","doseDates=" +caseDescription);
        return   apid+ca;
    }
}
