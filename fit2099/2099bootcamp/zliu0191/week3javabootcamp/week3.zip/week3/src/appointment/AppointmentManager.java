package appointment;

import java.util.HashMap;
import java.util.Scanner;

public class AppointmentManager implements AppointmentManagerInterface {
    private HashMap<Integer, Appointment> ap = new HashMap<Integer, Appointment>();


    // Maybe danger as appointment is an abstract
    @Override
    public void addAppointment(int patientId, int doctorId, String date, Appointment.AppointmentType appType) {

        if (appType == Appointment.AppointmentType.COVID){
        Appointment apadd= new Covid(patientId,doctorId,date,Appointment.AppointmentType.COVID);
        ap.put(apadd.getAppointmentId(),apadd);
        }
        if (appType == Appointment.AppointmentType.STANDARD){
            Appointment apadd= new Standard(patientId,doctorId,date,Appointment.AppointmentType.STANDARD);
            ap.put(apadd.getAppointmentId(),apadd);
        }

    }


    @Override
    public void cancelAppointment(int appointmentId) {
        ap.remove(appointmentId);
    }

    @Override
    public void printAppointments() {
        String line="----------------------------------------------------------";
        System.out.println(line);
        String colId=String.format("| %-10s ","ID");
        String app=String.format("| %-10s ","appointment");
        System.out.println(colId+app);
        System.out.println(line);

        for (Appointment appointment:ap.values()) {
            System.out.println(appointment.toString());
        }
        Scanner con=new Scanner(System.in);
        System.out.println("Enter to continue");
        con.nextLine();
    }
}
