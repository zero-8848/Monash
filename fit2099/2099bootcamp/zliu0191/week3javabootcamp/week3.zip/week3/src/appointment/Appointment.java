package appointment;
import tools.Utils;

public abstract class Appointment {
private int appointmentId;
private int patientId;
private int doctorId;
private String date;
public enum AppointmentType{
    COVID, STANDARD
}

    public Appointment(int patientId, int doctorId, String date, AppointmentType covid) {
        this.appointmentId = Utils.nextID(1000000,9999999);
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.date = date;
    }

    public int getAppointmentId() {
        return appointmentId;
    }

    public int getPatientId() {
        return patientId;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public String getDate() {
        return date;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
