package tools;

import java.util.Scanner;

public class MenuInput {
    public static int menuItem() {
        int choice=0;
        Scanner sel = new Scanner(System.in);
        System.out.println("+-------------------------------------+");
        System.out.println("|        Welcome to Bootcamp          |");
        System.out.println("|        Week 4  (Clinic App)         |");
        System.out.println("+-------------------------------------+");
        System.out.println("1) New Patient");
        System.out.println("2) New Doctor");
        System.out.println("3) List Patients");
        System.out.println("4) List Doctors");
        System.out.println("5) COVID Appointment");
        System.out.println("6) Standard Appointment");
        System.out.println("7) List Appointments");
        System.out.println("8) Cancel Appointment");
        System.out.println("9) Exit");
        System.out.print("Select one:");
        choice = Integer.parseInt(sel.nextLine());
        System.out.println("Your choice:"+choice);
        return choice;
    }
}
