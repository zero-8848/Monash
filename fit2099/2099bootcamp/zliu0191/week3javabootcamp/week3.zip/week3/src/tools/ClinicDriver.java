package tools;

import appointment.Appointment;
import clinic.Clinic;

import java.util.Scanner;
import appointment.AppointmentManager;

import static java.lang.Integer.parseInt;

public class ClinicDriver {
    public static void main(String[] args){
        Clinic monashClinic = new Clinic();
        AppointmentManager app=new AppointmentManager();
        int patientId,doctorId,appoinmentId;
        String date;
//        clinic.runClinic();
        Scanner sel = new Scanner(System.in);
        int selection;
        do {
            selection = MenuInput.menuItem();
            switch (selection) {
                case 1:
                    monashClinic.createPatient();
                    break;
                case 2:
                    monashClinic.createDoctor();
                    break;
                case 3:
                    monashClinic.listPatients();
                    break;

                case 4:
                    monashClinic.listDoctors();
                    break;
                case 5:
//                    Scanner sel = new Scanner(System.in);
                    System.out.print("Enter patient id");
                    patientId = sel.nextInt();
                    System.out.print("Enter clinic.Doctor id:");
                    doctorId =sel.nextInt();
                    System.out.print("Enter appointment date: ");
                    date = sel.nextLine();

                    app.addAppointment(patientId,doctorId,date, Appointment.AppointmentType.COVID);
                    enterToContinue();
                    break;
                case 6:
                    System.out.print("Enter patient id");
                    patientId = sel.nextInt();
                    System.out.print("Enter clinic.Doctor id:");
                    doctorId = sel.nextInt();
                    System.out.print("Enter appointment date: ");
                    date = sel.nextLine();
                    app.addAppointment(patientId,doctorId,date, Appointment.AppointmentType.STANDARD);
                    enterToContinue();
                    break;
                case 7:
                    app.printAppointments();
//                    enterToContinue();
                    break;
                case 8:
                    System.out.print("Enter appointment id");
                    appoinmentId = sel.nextInt();

                    app.cancelAppointment(appoinmentId);
                    enterToContinue();
                    break;
                case 9:
                    System.exit(0);


            }
        } while (selection != 9);


    }
    public static void enterToContinue(){
        Scanner con=new Scanner(System.in);
        System.out.println("Enter to continue");
        con.nextLine();
    }
}
