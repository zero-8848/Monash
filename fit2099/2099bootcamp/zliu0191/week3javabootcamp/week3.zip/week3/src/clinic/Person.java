package clinic;

public abstract class Person {
    private String fullName;
    private String address;
    protected int id;

    public Person(String fullName, String address) {
        this.fullName = fullName;
        this.address = address;
        //this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getAddress() {
        return address;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        String name=String.format(" %-10s |",getFullName());
        String address=String.format(" %-10s |",getAddress());
        return   name +address;
    }

    abstract public int generateId();

}
