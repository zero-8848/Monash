package clinic;

import tools.Utils;

public class Doctor extends Person {
    private String speciality;

    public Doctor(String fullName, String address,String speciality) {
        super(fullName, address);
        setSpeciality(speciality);
        setFullName(fullName);
        setAddress(address);
        this.id = generateId();
    }


    @Override
    public int generateId() {
        return Utils.nextID(100,999);
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    @Override
    public String toString() {
        String identity=String.format("| %-10s |",this.id+"");
        String spec=String.format(" %-10s |",getSpeciality());
        return
                identity+super.toString()+spec;

    }

}
