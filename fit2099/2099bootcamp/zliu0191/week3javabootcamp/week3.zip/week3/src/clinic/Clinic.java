package clinic;

import java.util.ArrayList;
import java.util.Scanner;

public class Clinic {
    private ArrayList<Patient> patients=new ArrayList<>();
    private ArrayList<Doctor> doctors=new ArrayList<>();




    public void createPatient() {
        String name, address, caseDesc;
        Scanner sel = new Scanner(System.in);
        System.out.print("Enter clinic.Patient Name:");
        name = sel.nextLine();
        System.out.print("Enter clinic.Patient Address:");
        address = sel.nextLine();
        System.out.print("Enter clinic.Patient Case: ");
        caseDesc = sel.next();
        Patient patient = new Patient(name, address, caseDesc);
        patients.add(patient);
    }
    public void listPatients(){
        String line="----------------------------------------------------------";
        System.out.println(line);
        String colId=String.format("| %-10s ","ID");
        String colName=String.format("| %-10s ","Name");
        String colAddress=String.format("| %-10s ","Address");
        String colCase=String.format("| %-10s |","Case");
        System.out.println(colId+colName+colAddress+colCase);
        System.out.println(line);

        for (int i = 0; i < patients.size(); i++) {
            System.out.println(patients.get(i));
        }
        Scanner con=new Scanner(System.in);
        System.out.println("Enter to continue");
        con.nextLine();
    }

    public void createDoctor() {
        String name, address, speciality;
        Scanner sel = new Scanner(System.in);
        System.out.print("Enter clinic.Doctor Name:");
        name = sel.nextLine();
        System.out.print("Enter clinic.Doctor Address:");
        address = sel.nextLine();
        System.out.print("Enter clinic.Doctor Speciality: ");
        speciality = sel.next();
        Doctor doctor = new Doctor(name, address, speciality);
        doctors.add(doctor);
    }
    public void listDoctors(){
        String line="----------------------------------------------------------";
        System.out.println(line);
        String colId=String.format("| %-10s ","ID");
        String colName=String.format("| %-10s ","Name");
        String colAddress=String.format("| %-10s ","Address");
        String colSp=String.format("| %-10s |","Speciality");
        System.out.println(colId+colName+colAddress+colSp);
        System.out.println(line);

        for (int i = 0; i < doctors.size(); i++) {
            System.out.println(doctors.get(i));
        }
        Scanner con=new Scanner(System.in);
        System.out.println("Enter to continue");
        con.nextLine();
    }

    public void runClinic(){
        System.out.println("Welcome to FIT2099 clinic.Clinic App");
        createPatient();
        listPatients();
        System.out.println("Thank you for visiting FIT2099 clinic.Clinic App");
    }

}

